﻿namespace P01_StudentSystem.Data.Models.Enumations
{
    public enum ContentType
    {
        Application = 10,
        Pdf = 20,
        Zip = 30
    }
}
