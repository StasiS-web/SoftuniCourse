﻿namespace P01_StudentSystem.Data
{
    public static class Configuration
    {
        public const string CONNECTION_STRING = @"Server=.;Database=StudentSystem;Integrated Security=True;";
    }
}