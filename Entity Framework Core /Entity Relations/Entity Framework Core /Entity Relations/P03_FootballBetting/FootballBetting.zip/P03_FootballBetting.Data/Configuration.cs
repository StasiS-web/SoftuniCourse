﻿using System;
namespace P03_FootballBetting.Data
{
    public static class Configuration
    {
        public const string CONNECTION_STRING = @"Server=.,1433;Database=DatabaseName;Integrated Security=True;";
    }
}
